package net.itinajero.app.service;

import net.itinajero.app.model.Noticia;

public interface INoticiasService {

	void guardar(Noticia noticia);
	
}
